# Linux Box

## Usage

You will need [`vagrant`](https://www.vagrantup.com) to manage the environment.

    vagrant up
    
will start a VM in GUI mode.  

The `target` project directory is accessible from a mount at `/app`.  
Scripts to launch a notification with each notifier are available in `/vagrant`.
