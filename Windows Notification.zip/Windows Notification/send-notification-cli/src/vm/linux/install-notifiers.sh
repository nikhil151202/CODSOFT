#!/usr/bin/env bash

sudo apt-get update
sudo apt-get -y install openjdk-7-jdk kubuntu-desktop python3-pip
pip3 install somebar
