#!/usr/bin/env bash
sudo apt-get -y install maven git
