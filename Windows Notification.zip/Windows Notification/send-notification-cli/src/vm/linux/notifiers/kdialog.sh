#!/usr/bin/env bash
./notify.sh kdialog
