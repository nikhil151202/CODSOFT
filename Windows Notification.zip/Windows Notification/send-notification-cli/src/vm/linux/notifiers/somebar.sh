#!/usr/bin/env bash

somebar &!
./notify.sh anybar
