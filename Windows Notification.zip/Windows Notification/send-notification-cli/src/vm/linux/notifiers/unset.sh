#!/usr/bin/env bash
/app/appassembler/bin/send-notification -m Message -t "Notification Title" -i "/app/classes/1417373522_geek_zombie.png" -s Subtitle
