#!/usr/bin/env bash
brew install terminal-notifier
brew cask install java
brew cask install anybar
