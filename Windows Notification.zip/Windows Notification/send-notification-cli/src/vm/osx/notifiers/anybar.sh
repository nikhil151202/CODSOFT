#!/usr/bin/env bash
open -n ~/Applications/AnyBar.app
./notify.sh anybar
