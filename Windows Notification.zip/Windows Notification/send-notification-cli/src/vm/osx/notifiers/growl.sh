#!/usr/bin/env bash
./notify.sh growl
