#!/usr/bin/env bash
./notify.sh simplenc
