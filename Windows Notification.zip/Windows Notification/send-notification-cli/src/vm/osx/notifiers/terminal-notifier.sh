#!/usr/bin/env bash
./notify.sh notificationcenter
