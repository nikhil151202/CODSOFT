package fr.jcgay.notification;

public interface IconFileWriter {

    void write(Icon icon);
}
